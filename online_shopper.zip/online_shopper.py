                    
#-----Statement of Authorship----------------------------------------#
#
#  This is an individual assessment item.  By submitting this
#  code I agree that it represents my own work.  I am aware of
#  the University rule that a student must not act in a manner
#  which constitutes academic dishonesty as stated and explained
#  in QUT's Manual of Policies and Procedures, Section C/5.3
#  "Academic Integrity" and Section E/2.1 "Student Code of Conduct".
#
#    Student no: N9878831
#    Student name: Deenalaththage Heshanka Sandali Deenalattha
#
#  NB: Files submitted without a completed copy of this statement
#  will not be marked.  Submitted files will be subjected to
#  software plagiarism analysis using the MoSS system
#  (http://theory.stanford.edu/~aiken/moss/).
#
#--------------------------------------------------------------------#



#-----Assignment Description-----------------------------------------#
#
#  Online Shopper
#
#  In this assignment you will combine your knowledge of HTMl/XML
#  mark-up languages with your skills in Python scripting, pattern
#  matching, and Graphical User Interface design to produce a useful
#  application for aggregating product data published by a variety of
#  online shops.  See the instruction sheet accompanying this file
#  for full details.
#
#--------------------------------------------------------------------#



#-----Imported Functions---------------------------------------------#
#
# Below are various import statements for helpful functions.  You
# should be able to complete this assignment using these
# functions only.  Note that not all of these functions are
# needed to successfully complete this assignment.

# The function for opening a web document given its URL.
# (You WILL need to use this function in your solution.)
import itertools
from urllib import urlopen

# Import the standard Tkinter functions. (You WILL need to use
# these functions in your solution.)
from Tkinter import *

# Functions for finding all occurrences of a pattern
# defined via a regular expression.  (You do NOT need to
# use these functions in your solution, although you will find
# it difficult to produce a robust solution without using
# regular expressions.)
from re import findall, finditer, sub

# Import the standard SQLite functions just in case they're
# needed.
from sqlite3 import *

#
#--------------------------------------------------------------------#

#-----Student's Solution---------------------------------------------#

# Name of the invoice file. To simplify marking, your program should
# produce its results using this file name.
#----------------------INTERFACE OF THE APPLICATION------------------#
#Creates a window
top = Tk()

#Window title      
top.title("Your JACK POT Online Shop")

#Heading frame
frameOne = Frame(top, height =200, width = 100)
frameOne.grid(row = 0, columnspan = 2, padx = 1, pady = 2)

#Step 1 frame
frameTwo = Frame(top, height =300, width = 100)
frameTwo.grid(row = 1, columnspan = 2, sticky = W, ipady =8)

#Step 2 frame
frameThree = Frame(top, height =200, width = 100)
frameThree.grid(row = 5, columnspan = 2, sticky = W)

#Step 3 frame
frameFour = Frame(top, height =400, width = 100)
frameFour.grid(row = 8, columnspan = 2, sticky = W)

#Step 4 frame
frameFive = Frame(top, height =200, width = 100)
frameFive.grid(row = 11, columnspan = 2, sticky = W)

#String variables of the labels
w = StringVar()
x = StringVar()
a = StringVar()
b = StringVar()
c = StringVar()
z = StringVar()
p = StringVar()
y = StringVar()
q = StringVar()

#Creates the Heading
label1 = Label(frameOne, textvariable = w, fg = 'blue', font=("Courier", 14, "bold"), wraplength = 250,justify = "center")
w.set("Welcome to 'JACK-POT' Online Shopping!")
label1.grid()

#creates the step 1 statement
label3 = Label(frameTwo, textvariable = x, fg ='hot pink', font=("Courier", 10, "bold"), justify = "right")
x.set("Step 1. Choose your Quantities")
label3.grid(row = 2, columnspan = 2, sticky = W,ipady=10)

#creates the spinbox 1 label
labela = Label(frameTwo, textvariable = a, wraplength = 100, padx = 40,font=("Courier", 8), justify = "right")
a.set("Women's T-shirts ")
labela.grid(row = 3, column = 0, sticky = E)

#creates the spinbox 2 label
labelb = Label(frameTwo, textvariable = b, wraplength = 100, padx=25, font=("Courier", 8), justify= "right")
b.set("Toys and Games ")
labelb.grid(row = 3, column = 1, sticky = W)

#creates the spinbox 3 label
labelc = Label(frameTwo, textvariable = c, wraplength = 100, padx = 40,font=("Courier", 8), justify = "right")
c.set("Computer Accesorries ")
labelc.grid(row = 4, column = 0, sticky = E)

#creates the step 3 statement
label5 = Label(frameFour, textvariable = z, fg ='dark green', font=("Courier", 10, "bold"), justify = "right")
z.set("Step 3. Watch your order's progress")
label5.grid(row = 9, columnspan = 2, sticky = W)

#creates the step 2 statement
label4 = Label(frameThree, textvariable = y, fg ='orange', font=("Courier", 10, "bold"), justify = "right")
y.set("Step 2. Print your invoice here")
label4.grid(row = 6, columnspan = 2, sticky = W)

#creates the status bar
label6 = Label(frameFour, textvariable = p, fg ='red', font=("Courier", 10))
p.set("Ready....")
label6.grid(row = 10, columnspan = 2, pady = 10)

#create the step 4 statement 
label7 = Label(frameFive, textvariable = q, fg ='purple', font=("Courier", 10, "bold"), justify = "right")
q.set("Step 4. Save your Order")
label7.grid(row = 12, columnspan = 2, sticky = W)

#creates the spinboxes
s_box1 = Spinbox(frameTwo, from_= 0, to = 9, width=3)
s_box1.grid(row = 3, column = 0, sticky = E)
s_box2 = Spinbox(frameTwo, from_= 0, to = 9, width=3)
s_box2.grid(row = 3, column = 1, sticky = W, padx = 100)
s_box3 = Spinbox(frameTwo, from_= 0, to = 9, width=3)
s_box3.grid(row = 4, column = 0, sticky = E)

#arrays to store the price, title and image of the item
value_li = []
Title_li = []
Image_li = []
tot = 0

def html_replace():    
    #get values of the spinbox
    i =(int(s_box1.get()))
    j =(int(s_box2.get()))
    k =(int(s_box3.get()))
    global tot
    tot = i+j+k
    
#first few lines of the html    
    front = """<!DOCTYPE html>
    <html>
    <head>
    <title>Your 'JACK-POT' invoice</title>
    <style>
    body {background-image: url('http://cdn.wallpapersafari.com/33/46/QCWw1E.jpg')}
    p {width: 500px; margin-left: auto; margin-right:auto}
    h1 {width: 500px; margin-left: auto; margin-right:auto}
    h2 {width: 400px; margin-left: auto; margin-right:auto}
    table {width: 500px; margin-left: auto; margin-right:auto}
    ul {width: 500px; margin-left: auto; margin-right:auto}
    </style>
    </head>

    <body>

    <h1 align="center"><em>JACK POT Trading Co.</em> Invoice</h1>
    <p><img src="http://media.harnesslink.mycms.co.nz/files/w400h320/81605/Jackpot+logo.jpg"
    alt = "JACK POT Logo" width=500px border="2"></p>
    """

#last few lines of the html
    end ="""
    <p align="left">The <em>JACK POT Trading Company</em> is proudly supported by:</p>
    <ul>
    <li>https://feed.zazzle.com/rss?qs=toys-and-games</li>
    <li>https://feed.zazzle.com/rss?qs=women's-tshirts</li>
    <li>https://feed.zazzle.com/rss?qs=computer-accessories</li>
    </ul>
    </body>
    </html>
    """

    global value_li
    global Title_li
    global Image_li
    
    #putting all the relevant amount of data in to one array
    for o in range(i):
        #RSS Feed Scraping
        url =urlopen("https://feed.zazzle.com/rss?qs=women's-tshirts").read() #i
        urlTitle = re.compile('alt="(.*)" title')
        urlImage = re.compile("<media:thumbnail url=(.*)/>")
        urlPrice = re.compile("<price>(.*)</price>")

        p.set('   Downloading Women T-shirt   ')
        frameFour.update_idletasks()
        urlfindPrice = re.findall(urlPrice, url)
        value_url = float(sub(r'[^\d.]', '', urlfindPrice[o]))
        value_url_aud = value_url*1.34
        value_3 = round(value_url_aud,2)
        value_li.append(value_3)
        urlfindTitle = re.findall(urlTitle, url)
        Title_li.append(urlfindTitle[o])
        urlfindImage = re.findall(urlImage, url)
        Image_li.append(urlfindImage[o])

    for m in range(j):
        #RSS Feed Scraping
        hrl =urlopen("https://feed.zazzle.com/rss?qs=toys-and-games").read() #j
        hrlTitle = re.compile('alt="(.*)" title')
        hrlImage = re.compile("<media:thumbnail url=(.*)/>")
        hrlPrice = re.compile("<price>(.*)</price>")

        p.set('   Downloading Toys and Games   ')
        frameFour.update_idletasks()
        hrlfindPrice = re.findall(hrlPrice, hrl)
        value_hrl = float(sub(r'[^\d.]', '', hrlfindPrice[m]))
        value_hrl_aud = value_hrl*1.34
        value_2 = round(value_hrl_aud,2)
        value_li.append(value_2)
        hrlfindTitle = re.findall(hrlTitle, hrl)
        Title_li.append(hrlfindTitle[m])
        hrlfindImage = re.findall(hrlImage, hrl)
        Image_li.append(hrlfindImage[m])

    for n in range(k):
        #RSS Feed Scraping
        xml =urlopen("https://feed.zazzle.com/rss?qs=computer-accessories").read() #k
        xmlTitle = re.compile('alt="(.*)" title')
        xmlImage = re.compile('<img id="page_zWidget[0-9]-preview" src="(.*) class')
        xmlPrice = re.compile("<price>(.*)</price>")

        p.set('Downloading Computer Accessories')
        frameFour.update_idletasks()
        xmlfindPrice = re.findall(xmlPrice,xml)
        value = float(sub(r'[^\d.]', '', xmlfindPrice[n]))
        value_aud = value*1.34
        value_1 = round(value_aud,2)
        value_li.append(value_1)
        xmlfindTitle = re.findall(xmlTitle,xml)
        Title_li.append(xmlfindTitle[n])
        xmlfindImage = re.findall(xmlImage,xml)
        Image_li.append(xmlfindImage[n])
    
    total = sum(value_li) #total value of the items purchased

    
    #writing to the html file
    with open('Invoice.html','w') as invoice:
        invoice.write(front)
        if tot != 0:
            invoice.write('<h2 align="center">Total for the purchases below: <br>$%s AUD</h2>' % (total))  
        elif tot == 0:
            invoice.write('<h2 align="center">Thank you browsing <br> Please call again</h2>')
        invoice.write('<table align="center">')
        count = 0
        for a,b,c in itertools.izip(Image_li, Title_li, value_li):
            if count % 2 == 0:
                invoice.write('<tr align="center">')
            invoice.write('<td><img src=%s<br><br>%s<br><br><span style="background-color:black; color:white">$%s AUD</span></td>' % (a,b,c)) #creates the table cells with the data in it
            count += 1
        if count % 2 == 0:
            invoice.write('</tr>')
        if count % 2 != 0:
            invoice.write('<td></td>')
            invoice.write('</tr>')
        invoice.write('</table>')
        p.set("Done!!")
        invoice.write(end)

#Save searched items in a database
def save_db():
    global value_li
    global Title_li
    global tot
 
    conn = connect(database = "shopping_trolley.db")

    with conn:

        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS Purchases") #deletes if there is any existing tables names purchases 
        cur.execute("CREATE TABLE Purchases(Description TEXT, Price TEXT)") #creating a new table with two columns 

        for i in range(tot):
            title = Title_li[i]
            value = "$"+str(value_li[i])
            cur.execute("INSERT INTO Purchases VALUES (?, ?)", (title, value)) #inserting data into the database

    conn.commit()

    p.set("Order Saved!")
    
    conn.close()
    
        
#create the button to generate the html
button = Button(frameThree, text="Print Invoice", command=html_replace, width = 15, font=("Courier", 9))
button.grid(row =7, columnspan = 2, pady=10)

#creates the button to save the order in the database
button1 = Button(frameFive, text="Save Order", command=save_db, width = 15, font=("Courier", 9))
button1.grid(row = 13, columnspan = 2, pady=10, sticky=E)

top.mainloop()
